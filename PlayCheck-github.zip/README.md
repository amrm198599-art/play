# Waleed Google Play – GitHub build

1. ارفع محتويات هذا المجلد كما هي على مستودع GitHub (الفرع `main`).
2. (اختياري للتوقيع) من Settings > Secrets and variables > Actions أضف:
   - `KEYSTORE_BASE64`  → ناتج `base64 -w0 upload-key.jks`
   - `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`
3. أي push على `main` (أو Actions > Run workflow) يفك `PlayCheck.zip` ويبني:
   debug APK + release APK + release AAB.
4. حمّل الناتج من صفحة الـ run تحت **Artifacts > android-build**.
   ولو عملت tag مثل `v1.0` يتم إرفاق الملفات في Releases.

بدون الأسرار يطلع release غير موقّع (`*-unsigned`) ولا يصلح للرفع على Play؛ استخدم الـ AAB الموقّع.
