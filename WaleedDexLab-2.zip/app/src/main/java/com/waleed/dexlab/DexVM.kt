package com.waleed.dexlab

import android.app.Application
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class DexVM(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("dexlab", Context.MODE_PRIVATE)
    private val ctx: Context get() = getApplication<Application>().applicationContext

    var project by mutableStateOf<File?>(null)
    var cwd by mutableStateOf<File?>(null)
    var status by mutableStateOf("")
    var busy by mutableStateOf(false)
    var apps by mutableStateOf<List<AppItem>>(emptyList())
    var pkgs by mutableStateOf<List<PkgFile>>(emptyList())
    var hits by mutableStateOf<List<Hit>>(emptyList())
    var signed by mutableStateOf<File?>(null)
    var autoDecompile by mutableStateOf(prefs.getBoolean("auto", true))

    fun setAuto(v: Boolean) { autoDecompile = v; prefs.edit().putBoolean("auto", v).apply() }

    private fun s(id: Int, vararg a: Any): String = ctx.getString(id, *a)

    private fun work(block: suspend () -> Unit) {
        viewModelScope.launch {
            busy = true
            try {
                withContext(Dispatchers.IO) { block() }
            } catch (t: Throwable) {
                status = "✗ " + (t.message ?: t.javaClass.simpleName)
            } finally {
                busy = false
            }
        }
    }

    fun loadApps() {
        if (apps.isNotEmpty()) return
        work { apps = Engine.installedApps(ctx) }
    }

    fun scanFiles() = work { pkgs = Engine.scan() }

    private fun finish(o: Opened) {
        signed = null
        hits = emptyList()
        cwd = o.dir
        project = o.dir
        status = s(R.string.ready, o.dir.name) + when (o.kind) {
            "AAB" -> "\n" + s(R.string.aab_note)
            "SPLIT" -> "\n" + s(R.string.split_note, o.splits)
            else -> ""
        }
    }

    /** Opens the project, then decompiles the DEX code to smali automatically (if enabled) */
    private fun afterOpen(o: Opened) {
        finish(o)
        if (autoDecompile) {
            val note = status
            status = s(R.string.decompiling)
            Engine.decompile(o.dir)
            status = note + "\n" + s(R.string.decompiled)
        }
    }

    private fun displayName(u: Uri): String =
        ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        } ?: u.lastPathSegment?.substringAfterLast('/') ?: "app.apk"

    /** Used for: file picker, "Open with", and "Share to" from other apps */
    fun openUri(u: Uri) = work {
        status = s(R.string.unpacking)
        val name = displayName(u)
        val tmp = File(ctx.cacheDir, "in.bin")
        ctx.contentResolver.openInputStream(u)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
        afterOpen(Engine.open(ctx, tmp, name))
    }

    fun openInstalled(a: AppItem) = work {
        status = s(R.string.unpacking)
        afterOpen(Engine.open(ctx, File(a.path), a.pkg + ".apk"))
    }

    fun openFile(p: PkgFile) = work {
        status = s(R.string.unpacking)
        afterOpen(Engine.open(ctx, p.file, p.name))
    }

    fun decompile() = work {
        val d = project ?: return@work
        status = s(R.string.decompiling)
        Engine.decompile(d)
        status = s(R.string.decompiled)
    }

    fun build() = work {
        val d = project ?: return@work
        if (File(d, "original.aab").exists()) { status = s(R.string.aab_note); return@work }
        status = s(R.string.building)
        val f = Engine.build(ctx, d)
        signed = f
        status = s(R.string.signed_ok, "%.1f MB".format(f.length() / 1048576.0))
    }

    fun search(q: String) = work { hits = Engine.search(project ?: return@work, q) }

    fun export(u: Uri) = work {
        val f = signed ?: return@work
        ctx.contentResolver.openOutputStream(u)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        status = s(R.string.exported)
    }

    fun close() { project = null; cwd = null; signed = null; hits = emptyList(); status = "" }
}
